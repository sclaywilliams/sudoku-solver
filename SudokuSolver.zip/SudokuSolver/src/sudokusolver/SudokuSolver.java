package sudokusolver;

import java.util.ArrayList;

/*
 * @author sclaywilliams
 */
public class SudokuSolver {
    
    
    /*
    empty
    {0, 0, 0, 0, 0, 0, 0, 0, 0}, 
            {0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0}, 
            {0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0}, 
            {0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0}, 
            {0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0},
    
    
    Sudoku.com difficulty puzzles
    
    easy (solved in 9 passes)
    {0, 0, 6, 0, 0, 0, 0, 0, 8}, 
            {0, 0, 0, 9, 0, 8, 7, 0, 1},
            {0, 7, 0, 5, 4, 0, 3, 0, 0}, 
            {8, 9, 0, 2, 5, 1, 0, 3, 7},
            {7, 6, 5, 8, 0, 3, 0, 4, 2}, 
            {0, 0, 1, 0, 0, 0, 0, 9, 5},
            {6, 0, 3, 1, 8, 0, 0, 0, 0}, 
            {4, 8, 0, 0, 0, 0, 0, 0, 3},
            {0, 0, 0, 0, 0, 4, 5, 0, 0},
    
    medium (solved in 16 passes)
    {0, 5, 0, 4, 9, 0, 6, 0, 7}, 
            {1, 0, 0, 0, 2, 6, 0, 9, 0},
            {0, 9, 0, 0, 0, 8, 0, 0, 0}, 
            {0, 0, 0, 1, 5, 9, 3, 2, 6},
            {0, 0, 0, 0, 0, 0, 0, 0, 9}, 
            {9, 0, 5, 0, 0, 0, 0, 0, 1},
            {0, 0, 0, 0, 8, 7, 0, 6, 3}, 
            {2, 7, 0, 6, 0, 3, 0, 0, 0},
            {0, 6, 0, 0, 0, 0, 7, 1, 0},
    
    hard (solved in 16 passes)
    {0, 0, 0, 0, 0, 0, 0, 6, 0}, 
            {4, 0, 2, 0, 0, 6, 0, 0, 0},
            {0, 1, 0, 9, 8, 0, 0, 0, 4}, 
            {0, 2, 0, 0, 7, 5, 0, 0, 0},
            {1, 0, 0, 0, 0, 0, 0, 5, 3}, 
            {7, 0, 4, 0, 0, 0, 2, 1, 0},
            {0, 0, 0, 0, 0, 0, 5, 0, 0}, 
            {0, 0, 0, 0, 0, 3, 0, 0, 9},
            {6, 3, 1, 0, 0, 0, 0, 2, 0},
    
    hard (solved in 13 passes)
    {0, 0, 9, 1, 3, 0, 0, 0, 0}, 
            {0, 0, 0, 7, 0, 4, 1, 0, 0},
            {1, 0, 0, 5, 0, 8, 0, 7, 0}, 
            {3, 4, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 2, 5, 0, 0, 0, 3}, 
            {7, 2, 6, 0, 0, 9, 0, 0, 1},
            {0, 0, 0, 0, 0, 0, 0, 5, 0}, 
            {6, 8, 0, 0, 0, 0, 4, 0, 0},
            {0, 5, 0, 0, 0, 3, 0, 1, 7},
    
    hard (solved in 19 passes)
    {0, 9, 0, 5, 0, 0, 0, 0, 8}, 
            {0, 3, 5, 0, 0, 0, 0, 0, 0},
            {7, 0, 0, 0, 9, 0, 0, 0, 6}, 
            {0, 0, 0, 0, 5, 0, 3, 0, 0},
            {3, 0, 1, 7, 0, 0, 2, 0, 0}, 
            {8, 0, 0, 0, 4, 0, 1, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0}, 
            {1, 0, 0, 0, 7, 0, 0, 0, 4},
            {9, 0, 0, 0, 0, 2, 8, 0, 0},
    
    expert (solved in 20 passes)
    {8, 0, 0, 0, 2, 6, 4, 0, 0}, 
            {9, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 8, 0, 1, 0, 0, 6}, 
            {5, 0, 0, 0, 0, 0, 2, 0, 7},
            {0, 0, 0, 0, 0, 0, 0, 9, 5}, 
            {0, 0, 0, 2, 0, 4, 0, 0, 0},
            {0, 0, 0, 0, 7, 9, 0, 0, 0}, 
            {0, 1, 0, 5, 0, 0, 6, 0, 0},
            {0, 3, 4, 0, 0, 0, 0, 0, 0},
    
    expert (solved in 14 passes)
    {0, 0, 0, 1, 6, 4, 0, 0, 0}, 
            {0, 0, 0, 3, 0, 0, 0, 0, 7},
            {0, 0, 0, 8, 0, 0, 2, 0, 3}, 
            {0, 2, 0, 0, 0, 0, 0, 9, 5},
            {0, 8, 0, 0, 0, 6, 0, 0, 0}, 
            {0, 0, 3, 0, 9, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 4, 0, 0}, 
            {6, 0, 0, 0, 8, 0, 1, 0, 0},
            {1, 0, 4, 0, 0, 0, 0, 3, 0},
    
    expert (solved in 16 passes)
    {7, 2, 0, 0, 0, 0, 0, 0, 5}, 
            {0, 1, 0, 0, 8, 0, 0, 2, 0},
            {0, 0, 0, 0, 0, 0, 0, 7, 0}, 
            {0, 0, 0, 0, 0, 5, 9, 0, 0},
            {0, 0, 0, 7, 1, 2, 0, 0, 0}, 
            {0, 0, 0, 0, 0, 8, 5, 3, 0},
            {0, 0, 3, 0, 0, 0, 4, 0, 6}, 
            {5, 0, 0, 0, 6, 0, 0, 0, 0},
            {0, 0, 8, 1, 0, 0, 0, 0, 0},
    
    expert (unsolved)
    {0, 0, 0, 0, 3, 0, 0, 0, 9}, 
            {0, 0, 0, 0, 0, 5, 0, 6, 0},
            {0, 0, 0, 0, 0, 7, 5, 0, 8}, 
            {0, 0, 6, 0, 0, 0, 0, 0, 0},
            {3, 2, 0, 0, 0, 0, 6, 0, 0}, 
            {0, 0, 0, 0, 8, 0, 0, 5, 4},
            {0, 3, 0, 0, 5, 0, 0, 0, 0}, 
            {8, 1, 0, 9, 4, 3, 0, 0, 0},
            {9, 0, 0, 0, 0, 8, 0, 0, 0},
    
    evil (unsolved)
    {0, 8, 0, 1, 0, 5, 0, 2, 3}, 
            {0, 0, 0, 0, 2, 0, 0, 0, 0},
            {9, 0, 0, 0, 0, 0, 0, 4, 0}, 
            {0, 0, 0, 0, 8, 0, 0, 0, 2},
            {0, 6, 0, 0, 7, 0, 0, 0, 0}, 
            {0, 0, 4, 2, 0, 6, 0, 3, 0},
            {0, 5, 0, 6, 0, 3, 0, 0, 1}, 
            {0, 0, 0, 0, 0, 7, 0, 0, 0},
            {0, 0, 8, 0, 0, 0, 5, 0, 0},
    */
    
    
    // Starting board (0 = empty space) //
    static final int board[][] = { 
            {7, 2, 0, 0, 0, 0, 0, 0, 5}, 
            {0, 1, 0, 0, 8, 0, 0, 2, 0},
            {0, 0, 0, 0, 0, 0, 0, 7, 0}, 
            {0, 0, 0, 0, 0, 5, 9, 0, 0},
            {0, 0, 0, 7, 1, 2, 0, 0, 0}, 
            {0, 0, 0, 0, 0, 8, 5, 3, 0},
            {0, 0, 3, 0, 0, 0, 4, 0, 6}, 
            {5, 0, 0, 0, 6, 0, 0, 0, 0},
            {0, 0, 8, 1, 0, 0, 0, 0, 0},
        };

    
    public static void main(String[] args) {
        
        
        SudokuSolver solver = new SudokuSolver();
        
        ArrayList squares = new ArrayList<Square>();
        
        // Create and initialise rows, columns, and boxes //
        Row[] rows = new Row[9];
        Column[] columns = new Column[9];
        Box[] boxes = new Box[9];
        
        for (int i = 0; i < 9; i++) {
            rows[i] = new Row();
            columns[i] = new Column();
            boxes[i] = new Box();
        }
        
        // converts 2D array into more usable data structures //
        solver.fillBoard(board, squares, rows, columns, boxes);
        
        System.out.println("Initial board: ");
        solver.printBoard(rows);
        
        boolean unsolved = true;
        int runLoops = 0;
        
        while (unsolved) {
            
            // only tries harder algorithms if previous algorithm does nothing //
            if (!solver.checkShapes(rows, columns, boxes)) {
                if (!solver.boxLineInteraction(rows, columns, boxes)) {
                    if (solver.boxBoxInteraction(boxes)) {
                        /*
                        System.out.println("Box box interaction worked! " + runLoops);
                        for (int i = 0; i < 9; i++) {
                            System.out.println("\nSquare " + i + ": ");
                            boxes[5].squares[i].printPossibilities();
                        }
                        */
                    }
                    
                }
            }
            
            if (solver.checkIfSolved(squares, rows, columns, boxes)) {
                unsolved = false;
            }
            runLoops++;
            
            if (runLoops > 100) {
                System.out.println("Failure... The sudoku could not be solved...");
                solver.printBoard(rows);
                break;
            }
        }
        
        if (!unsolved) {
            System.out.println("Success! The sudoku has been solved in " + runLoops + " passes!");
            solver.printBoard(rows);
        }
    
        
    }
    
    // This converts the 2D array into a list of 81 squares, 9 rows, 9 columns, and 9 boxes //
    private void fillBoard(int[][] board, ArrayList squares, Row[] rows, Column[] columns, Box[] boxes) {

        // looping through rows //
        for (int i = 0; i < 9; i++) {   
            
            // looping through columns //
            for (int j= 0; j < 9; j++) {
                
                Square square = new Square(j, i, board[i][j]);
                
                // adds square to the list of 81 squares //
                squares.add(square);
                
                // fills rows one row at a time //
                rows[i].squares[j] = square;
                
                // fills columns one row at a time //
                columns[j].squares[i] = square;
                
                /* fills boxes using telephone grid order, each big box contains 
                   a smaller box ordered the same way (9 boxes of 9 squares)         
                    
               e.g. -------------
                    | 0 | 1 | 2 |
                    -------------
                    | 3 | 4 | 5 |
                    -------------
                    | 6 | 7 | 8 |
                    -------------                
                */
                boxes[j/3 + (i/3)*3].squares[j%3 + (i%3)*3] = square;
                
            }
        }
    }
    
    // Checks each shape (row, column, box) to remove possibilities based on filled in squares //
    private boolean checkShapes(Row[] rows, Column[] columns, Box[] boxes) {
        int flag = 0;
        for (int i = 0; i < 9; i++) {
            if (rows[i].check() || columns[i].check() || boxes[i].check())
                flag++;
        }
        return (flag > 0);
    }
    
    /*
        This function looks at each box, and finds any pairs of squares that are the only two squares
        in that box containing a certain possibility. It then checks if they are in the same row or 
        column, and if they are, it then removes that value as a possibility from the rest of the squares
        within the same row/column.
    */
    private boolean boxLineInteraction(Row[] rows, Column[] columns, Box[] boxes) {
        int flag = 0;
        
        // looping through boxes //
        for (int box = 0; box < 9; box++) {
            
            int[] values = boxes[box].getPossibilityTotals();
            
            // looping through values array //
            for (int i = 1; i <= 9; i++) {
                ArrayList<Square> squarePairs = new ArrayList<>();
                
                if (values[i] == 2) {
                    
                    // looping through squares within the box to find the pair //
                    for (int j = 0; j < 9; j++) {
                        if (boxes[box].squares[j].containsPossibility(i)) {
                            squarePairs.add(boxes[box].squares[j]);
                        }
                    }

                    Square s1 = squarePairs.get(0);
                    Square s2 = squarePairs.get(1);

                    // checking if the pair is in the same row //
                    if (s1.getRow() == s2.getRow()) {
                        // removing values[i] as a possibility from all other squares in the row //
                        for (int column = 0; column < 9; column++) {
                            if (column != s1.getColumn() && column != s2.getColumn()) {
                                if (rows[s1.getRow()].squares[column].removePossibility(i)) {
                                    flag++;
                                }
                            }
                        }
                    }
                    
                    // checking if the pair is in the same column //
                    else if (s1.getColumn() == s2.getColumn()) {
                        // removing values[i] as a possibility from all other squares in the column //
                        for (int row = 0; row < 9; row++) {
                            if (row != s1.getRow() && row != s2.getRow()) {
                                if (columns[s1.getColumn()].squares[row].removePossibility(i)) {
                                    flag++;
                                }
                            }
                        }
                    }
                }
            }
        }
        return (flag > 0);
    }
    
    
    
    // This function is long and hard to explain, best idea is to google "sudoku block-block interaction" //
    // it could probably be improved/optimised, but this works, so here it stays...                       //
    private boolean boxBoxInteraction(Box[] boxes) {
        int flag = 0;
        
        // loop through the first 8 boxes (last one is redundant as all possibilities will have been checked) //
        for (int box = 0; box < 8; box++) {
            
            int boxRow = box/3;      // stores box row as an int between 0-2 //
            int boxColumn = box%3;   // store box column as an int between 0-2 //
            
            // loop through possibilities //
            for (int p = 1; p <= 9; p++) {
                
                int[] checkedRows = boxes[box].checkRows(p);       // checkedRows[3]: if checkedRows[i] == 0, that row does not contain possibility p //
                int[] checkedColumns = boxes[box].checkColumns(p); // checkedColumns[3]: if checkedColumns[i] == 0, that column does not contain possibility p //
                
                // used for checking if an empty row/column exists in the square //
                int emptyRowCount = 0;
                int emptyRow = -1;
                int emptyColumnCount = 0;
                int emptyColumn = -1;
                
                // checking for a single empty row/column //
                for (int i = 0; i < 3; i++) {
                    if (checkedRows[i] == 0) {
                        emptyRow = i;
                        emptyRowCount++;
                    }
                    if (checkedColumns[i] == 0) {
                        emptyColumn = i;
                        emptyColumnCount++;
                    } 
                }
                
                // single empty row means a possible box-box interaction //
                if (emptyRowCount == 1) {
                    
                    // looping through the remaining boxes in the row to find one with a matching empty row //
                    for (int b = 1; b <= 2 - boxColumn; b++) {
                        
                        // finding a matching empty row //
                        if (boxes[box + b].checkRow(emptyRow, p)) {
                            
                            int nextBox = -1; // storing index of box to remove possibilities from //
                            
                            // switch statement is used to see how many boxes it had to loop through to //
                            // find a match, it then uses that info to find the unmatched box           //
                            switch (b) {
                                case 1 -> {
                                    nextBox = box + 2;
                                    if (nextBox/3 != boxRow) {
                                        nextBox -= 3;
                                    }
                                }
                                case 2 -> {
                                    nextBox = box + 1;
                                }
                            }
                            
                            // looping through box to remove all instances of possibility 'p' from all squares not in our empty row //
                            for (int sq = 0; sq < 9; sq++) {
                                if (boxes[nextBox].squares[sq].getRow()%3 != emptyRow) {
                                    if (boxes[nextBox].squares[sq].removePossibility(p)) {
                                        flag++;
                                    }
                                }
                            } 
                        }
                    }
                }
                // single empty column means a possible box-box interaction //
                if (emptyColumnCount == 1) {
                    
                    // looping through the remaining boxes in the column //
                    for (int b = 1; b <= 2 - boxRow; b++) {
                        
                        if (boxes[box + 3*b].checkColumn(emptyColumn, p)) {
                            
                            int nextBox = -1; // storing index of box to remove possibilities from //
                            
                            // switch statement is used to see how many boxes it had to loop through to //
                            // find a match, it then uses that info to find the unmatched box           //
                            switch (b) {
                                case 1 -> {
                                    nextBox = box + 3*2;
                                    if (nextBox/3 >= 3) {
                                        nextBox = nextBox % 3;
                                    }
                                }
                                case 2 -> {
                                    nextBox = box + 3;
                                }
                            } 
                            
                            // looping through box to remove all instances of possibility 'p' from all squares not in our empty column //
                            for (int sq = 0; sq < 9; sq++) {
                                if (boxes[nextBox].squares[sq].getColumn()%3 != emptyColumn) {
                                    if (boxes[nextBox].squares[sq].removePossibility(p)) {
                                        flag++;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return (flag > 0);
    }
    
    
    
    // Checks to see if all squares are filled, and totals of each set add to 45 //
    private boolean checkIfSolved(ArrayList<Square> squares, Row[] rows, Column[] columns, Box[] boxes) {
        for (int i = 0; i < 81; i++) {
            if (squares.get(i).getValue() == 0) {
                return false;
            }
        }
        for (int i = 0; i < 9; i ++) {
            int rowTotal = 0;
            int columnTotal = 0;
            int boxTotal = 0;
            for (int j = 0; j < 9; j++) {
                rowTotal += rows[i].squares[j].getValue();
                columnTotal += columns[i].squares[j].getValue();
                boxTotal += boxes[i].squares[j].getValue();
            }
            if (rowTotal != rows[i].getTotal() || columnTotal != rows[i].getTotal() || boxTotal != boxes[i].getTotal()) {
                return false;
            }
        }
        return true;
    }
    
    private void printBoard(Row[] rows) {
        
        for (int i = 0; i < 9; i++) {
            System.out.println("-------------------------------------");
            for (int j = 0; j < 9; j++) {
                if (rows[i].squares[j].getValue() == 0) {
                    System.out.print("|   "); // used for initial and unsolved boards //
                } else {
                    System.out.print("| " + rows[i].squares[j].getValue() + " ");
                }
            }
            System.out.println("|");
        }
        System.out.println("-------------------------------------\n");
    }
    
    
    
}
