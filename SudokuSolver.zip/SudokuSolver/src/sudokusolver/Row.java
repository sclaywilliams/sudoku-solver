package sudokusolver;

/**
 *
 * @author sclaywilliams
 */
public class Row extends Shape {
    
    public Row() {
        
    }
    
    
    
}
