package sudokusolver;

/**
 *
 * @author sclaywilliams
 */
public class Column extends Shape {
    
    public Column() {
        
    }
    
}
