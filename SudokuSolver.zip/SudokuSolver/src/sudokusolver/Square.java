package sudokusolver;

import java.util.ArrayList;

/**
 *
 * @author sclaywilliams
 */
public class Square {
    
    private ArrayList<Integer> possibilities;
    private int value;
    private int x;
    private int y;
    
    public Square(int x, int y, int value) {
        this.x = x;
        this.y = y;
        this.value = value;
        possibilities = new ArrayList<>();
        
        if (value != 0) {
            possibilities.add(value);
        } else {
            for (int i = 1; i <= 9; i++) {
                possibilities.add(i);
            }
        }
    }
    
    public int getColumn() {
        return x;
    }
    
    public int getRow() {
        return y;
    }
    
    public int getBox() {
        return (x/3 + (y/3)*3);
    }
    
    public int getBoxRow() {
        return x%3;
    }
    
    public int getBoxColumn() {
        return y%3;
    }
    
    public int getValue() {
        return value;
    }
    
    public void setValue(int value) {
        this.value = value;
        possibilities.clear();
        possibilities.add(value);
    }
    
    public ArrayList<Integer> getPossibilities() {
        return possibilities;
    }
    
    public int getNumberOfPossibilities() {
        return possibilities.size();
    }
    
    public boolean containsPossibility(int possibility) {
        return possibilities.contains(possibility);
    }
    
    public boolean containsPossibilities(ArrayList<Integer> possibilities) {
        return this.possibilities.containsAll(possibilities);
    }
    
    public boolean removePossibility(int possibility) {
        if (possibilities.contains(possibility)) {
            possibilities.remove(possibilities.indexOf(possibility));
            if (possibilities.size() == 1) {
                value = possibilities.get(0);
            }
            return true;
        } else {
            return false;
        }
    }
    
    public boolean removePossibilities(ArrayList<Integer> possibilities) {
        return this.possibilities.removeAll(possibilities);
    }
    
    public void printPossibilities() {
        System.out.println("Row: " + getRow() + " | Column: " + getColumn());
        for (int possibility : possibilities) {
            System.out.print(possibility + " ");
        }
        System.out.println();
    }
    
    
}
