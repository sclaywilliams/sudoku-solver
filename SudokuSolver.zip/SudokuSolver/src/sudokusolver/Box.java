package sudokusolver;

/**
 *
 * @author sclaywilliams
 */
public class Box extends Shape {
    
    public Box() {

    }
    
    // checks to see if any square in the row contains a set possibility //
    public boolean checkRow(int row, int possibility) {
        for (int c = 0; c < 3; c++) {
            if (squares[(row*3) + c].containsPossibility(possibility)) {
                return false;
            }
        }
        return true;
    }
    
    // checks to see if any square in the column contains a set possibility //
    public boolean checkColumn(int column, int possibility) {
        for (int r = 0; r < 3; r++) {
            if (squares[column + (r*3)].containsPossibility(possibility)) {
                return false;
            }
        }
        return true;
    }
    
    // checks each row, and tallys the number of times a set possibility is found in the row //
    // (used for finding an empty row, if any value of checkedRows[] is 0)                   //
    public int[] checkRows(int possibility) {
        
        int[] checkedRows = new int[3];
        
        for (int sq = 0; sq < 9; sq++) {
            Square square = squares[sq];
            if (square.containsPossibility(possibility)) {
                checkedRows[square.getRow()%3]++;
            }
        }
        return checkedRows;
    }
    
    // checks each column, and tallys the number of times a set possibility is found in the column //
    // (used for finding an empty column, if any value of checkedColumns[] is 0)
    public int[] checkColumns(int possibility) {
        
        int[] checkedColumns = new int[3];
        
        for (int sq = 0; sq < 9; sq++) {
            Square square = squares[sq];
            if (square.containsPossibility(possibility)) {
                checkedColumns[square.getColumn()%3]++;
            }
        }
        return checkedColumns;
    }
    
}
