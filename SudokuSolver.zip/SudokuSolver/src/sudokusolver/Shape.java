package sudokusolver;

import java.util.ArrayList;

/**
 *
 * @author sclaywilliams
 */
public class Shape {
    
    private static final int TOTAL = 45;  // all rows, columns, and boxes should add to 45 //
    public Square[] squares;
    
    public Shape() {
        
        squares = new Square[9];
    }
    
    public int getTotal() {
        return TOTAL;
    }
    
    // Broad spectrum check using all algorithms //
    public boolean check() {
        int flag = 0;
        
        if (clearPossibilities() || soleSurvivor() || nakedSubset() || hiddenSubset()) {
            flag++;
        }
        return (flag > 0);
    }
    
    
    // This checks a squares value, and removes that as a possibility for all the other squares in the same shape //
    private boolean clearPossibilities() {
        int flag = 0;
        for (int i = 0; i < 9; i++) {
            if (squares[i].getValue() != 0) {
               for (int j = 0; j < 9; j++) {
                   if (j != i) {
                       if (squares[j].removePossibility(squares[i].getValue())) {
                           flag++;
                       }
                   }
               } 
            }
        }
        return (flag > 0);
    }
    
    
    // This checks to see if only one square in a shape has a single possibility and sets that as its final value if true //
    private boolean soleSurvivor() {
        int flag = 0;
        
        int[] values = getPossibilityTotals();
        
        // checks values array to see if there are any possibilities contained //
        // in only one square, and then assigns that value to the square       //
        
        int survivor;
        
        for (int i = 1; i <= 9; i++) {
            if (values[i] == 1) {
                survivor = i;
                for (int j = 0; j < 9; j++) {
                    if (squares[j].containsPossibility(survivor)) {
                        squares[j].setValue(survivor);
                    }
                }
            }
        }
        return (flag > 0);
    }
    
    // looks for naked subset pairings within each shape and eliminates possibilities //
    private boolean nakedSubset() {
        int flag = 0;
        
        // checks for pairings of 2, 3, and 4 possibilities //
        for (int nPoss = 2; nPoss <= 4; nPoss++) {
            
            ArrayList<Square> subset = new ArrayList<>();
            
            for (int sq = 0; sq < 9; sq++) {
                if (squares[sq].getNumberOfPossibilities() == nPoss) {
                    subset.add(squares[sq]);
                }
            }
            // if x number of squares only have x number of possibilities that all match, //
            // no other squares in the set can have those possibilities                   //
            if (subset.size() == nPoss) {
                if (compareSubset(subset)) {
                    for (int sq = 0; sq < 9; sq++) {
                        if (!subset.contains(squares[sq])) {
                            if (squares[sq].removePossibilities(subset.get(0).getPossibilities())) {
                                flag++;
                            }
                        }
                    }
                }
            }
            
        }
        
        return (flag > 0);
    }
    
    
    
    private boolean hiddenSubset() {
        int flag = 0;
        
        int[] values = getPossibilityTotals();
        
        for (int nPoss = 2; nPoss <= 4; nPoss++) {
            
            ArrayList<Square> subset = new ArrayList<>();
            
            ArrayList<Integer> subsetPoss = new ArrayList<>();
            
            for (int v = 1; v <= 9; v++) {
                
                if (values[v] == nPoss) {
                    subsetPoss.add(v);
                }
                
            }
            // checking if squares have the right number of the right possibilities //
            if (subsetPoss.size() == nPoss) {
                for (int sq = 0; sq < 9; sq++) {
                    if (squares[sq].containsPossibilities(subsetPoss)) {
                        subset.add(squares[sq]);
                    }
                }
                // checking if nPoss squares have matching possibilities //
                if (subset.size() == nPoss) {
                    for (int v = 1; v <= 9; v++) {
                        int sqCount = 0;
                        // looking for a hidden subset //
                        if (values[v] == nPoss + 1) {
                            for (Square s : subset) {
                                if (s.containsPossibility(v)) {
                                    sqCount++;
                                }
                            }
                            if (sqCount == nPoss) {
                                for (int sq = 0; sq < 9; sq++) {
                                    if (!subset.contains(squares[sq]) && squares[sq].containsPossibility(v)) {
                                        squares[sq].setValue(v);
                                        flag++;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return (flag > 0);
    }
    
    public int[] getPossibilityTotals() {
        
        int[] values = new int[10]; // array for storing totals of each possibility in the shape //
        
        // fills array with totals of each possibility //
        for (int i = 0; i < 9; i++) {
            ArrayList<Integer> possibilities = squares[i].getPossibilities();
            for (int possibility : possibilities) {
                values[possibility]++;
            }
        }
        return values;
    }
    
    private boolean compareSubset(ArrayList<Square> subset) {
        
        // compares possibility lists of each square in the subset, and returns false if any don't match //
        for (int i = 1; i < subset.size(); i++) {
            for (int j = 0; j < subset.size(); j++) {
                if (subset.get(i).getPossibilities().get(j) != subset.get(i - 1).getPossibilities().get(j)) {
                    return false;
                }
            }
        }
       return true;
    }
    
}
